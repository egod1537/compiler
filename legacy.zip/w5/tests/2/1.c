int main() {
    int a, b;
    a = 1;
    b = (a = 3, a + 2);
    return b;
}
