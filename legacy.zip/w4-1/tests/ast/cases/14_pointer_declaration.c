int *p;
int **pp;
