int (*fp)(int);
