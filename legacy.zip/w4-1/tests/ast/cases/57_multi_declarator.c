int a, b, c;
