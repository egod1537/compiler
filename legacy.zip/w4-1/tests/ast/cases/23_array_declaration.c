int a[10];
