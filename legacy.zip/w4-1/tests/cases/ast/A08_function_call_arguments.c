int add(int left, int right)
{
    return left + right;
}

int main()
{
    return add(1, 2);
}
