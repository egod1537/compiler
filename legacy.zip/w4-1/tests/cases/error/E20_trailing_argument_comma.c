int identity(int value)
{
    return value;
}

int main()
{
    return identity(1,);
}
