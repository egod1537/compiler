struct Point {
    int x;
    int x;
};
