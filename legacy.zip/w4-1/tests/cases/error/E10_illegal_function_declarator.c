int value[1]
{
    return 0;
}
