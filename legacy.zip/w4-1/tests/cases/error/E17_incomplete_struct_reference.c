struct Missing *value;
