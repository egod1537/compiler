enum Missing *value;
