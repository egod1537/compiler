int empty()
{
}
