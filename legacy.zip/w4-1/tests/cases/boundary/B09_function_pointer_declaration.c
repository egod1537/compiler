int (*handler)(int value);
