int answer = 42;
