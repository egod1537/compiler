int global_value;
