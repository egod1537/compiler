int first, second, third;
