int (*matrix)[3];
