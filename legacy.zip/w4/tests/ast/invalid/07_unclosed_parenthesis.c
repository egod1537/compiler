int main()
{
    int value;
    value = (1 + 2;
    return value;
}
