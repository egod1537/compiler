static int value;
