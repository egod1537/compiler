extern int value;
