auto int value;
