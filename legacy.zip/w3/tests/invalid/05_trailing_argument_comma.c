int add(int left, int right)
{
    return left + right;
}

int main(void)
{
    return add(1, );
}
